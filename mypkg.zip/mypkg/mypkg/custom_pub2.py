#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from custom_interfaces.msg import MyPgkMsg
import random

class CustomPublisher(Node):
    def __init__(self, robot_name):
        super().__init__('robot_state_publisher_' + robot_name)
        self.publisher_ = self.create_publisher(MyPgkMsg, f'{robot_name}/state', 10)
        self.robot_name = robot_name
        timer_period = 1.0
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.get_logger().info('Custom Publisher has been started')

    def timer_callback(self):
        msg = MyPgkMsg()
        msg.vel.linear.x = 1.0
        msg.vel.linear.y = 0.0
        msg.vel.linear.z = 0.0
        msg.vel.angular.x = 0.0
        msg.vel.angular.y = 0.0
        msg.vel.angular.z = 0.0
        msg.power = random.randint(0,12)
        msg.altitude = random.uniform(0.0,12.0)
        msg.drone_name = f'{self.robot_name}'
        self.publisher_.publish(msg)
        print(f"Publishing: {msg.drone_name}")

def main(args = None):
    rclpy.init(args=args)
    robot_name = 'robot1'  # Dynamically assign robot name
    robot_state_publisher = CustomPublisher(robot_name)
    rclpy.spin(robot_state_publisher)
    robot_state_publisher.destroy_node()
    rclpy.shutdown()

    if __name__ == '__main__':
        main()