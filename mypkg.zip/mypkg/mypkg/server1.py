import rclpy
from rclpy.node import Node
from custom_interfaces.srv import MyPkgSrv
from builtin_interfaces.msg import Time


class TimeService(Node):
    def __init__(self):
        super().__init__('my_service')
        self.srv_ = self.create_service(MyPkgSrv, 'get_status', self.get_status_cb)
        self.get_logger().info('Time Service Started')
        self.threshold = 10.0

    def get_status_cb(self, request, response):
        self.get_logger().info(f'Request received: {request.id}')
            # current_time = self.get_clock().now().to_msg() #converts time to message ros format
            # print("hi lodu ")
            # response.res = current_time
        if request.crop_yield>self.threshold and request.operational_status == 'idle':
            response.harvesting_schedule = "scheduled harvesting for robot"
            response.status = True

        else:
            response.harvesting_schedule = "waiting for robot to be free"  #this constructor does not take any argument, so it will give 0 sec. 0nanosec as output
            response.status = False

        return response

def main(args = None):
    rclpy.init(args = args)
    time_service = TimeService()

    rclpy.spin(time_service)
    rclpy.shutdown()

if __name__ == '__main__':
    main()