#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from custom_interfaces.msg import MyPgkMsg

class CustomSubscriber(Node):
    def __init__(self):
        super().__init__('custom_subscriber')
        self.robot_states = {}  # Store states of all robots
        self.create_subscription(MyPgkMsg, 'robot1/state', self.robot_state_callback, 10)
        self.create_subscription(MyPgkMsg, 'robot2/state', self.robot_state_callback, 10)
        self.get_logger().info('Custom subscriber has been started')

    def robot_state_callback(self,msg):
        self.robot_states[msg.drone_name] = msg
        log_message = (
        f"Robot Data - {msg.drone_name}: {msg.power}% "
        f"Velocity - {msg.vel.linear.x}, {msg.vel.linear.y}, {msg.vel.linear.z}"
    )
    # Use a single argument for the logger info method
        self.get_logger().info(log_message)
#  self.get_logger().info(f"Robot Data - {msg.drone_name}: {msg.power}%",f"Velocity - {msg.vel.linear.x}, {msg.vel.linear.y}")


def main(args = None):
    rclpy.init(args=args)
    custom_subscriber = CustomSubscriber()
    rclpy.spin(custom_subscriber)
    rclpy.shutdown()

    if __name__ == '__main__':
        main()