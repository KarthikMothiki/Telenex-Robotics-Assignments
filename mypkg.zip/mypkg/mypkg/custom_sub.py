#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from custom_interfaces.msg import MyPkgMsg

class CustomSubscriber(Node):
    def __init__(self):
        super().__init__('custom_subscriber')
        self.robot_states = {}  # Store states of all robots
        self.create_subscription(MyPkgMsg, 'robot1/state', self.robot_state_callback, 10)
        self.create_subscription(MyPkgMsg, 'robot2/state', self.robot_state_callback, 10)
        self.get_logger().info('Custom subscriber has been started')
        self.create_timer(5.0, self.assign_task)  # Task assignment every 5 seconds


    def robot_state_callback(self,msg):
        self.robot_states[msg.robot_name] = msg
        self.get_logger().info(f"Received state from {msg.robot_name}: {msg.battery_level}%, {msg.task_status}")

    def assign_task(self):
        idle_robots = [robot for robot, state in self.robot_states.items() if state.task_status == 'Idle']

        if idle_robots:
            assigned_robot = idle_robots[0]  
            self.get_logger().info(f"Assigned task to {task_msg.robot_name}: {task_msg.task_description}")
        else:
            self.get_logger().info("No idle robots available for task assignment.")


def main(args = None):
    rclpy.init(args=args)
    custom_subscriber = CustomSubscriber()
    rclpy.spin(custom_subscriber)
    rclpy.shutdown()

    if __name__ == '__main__':
        main()