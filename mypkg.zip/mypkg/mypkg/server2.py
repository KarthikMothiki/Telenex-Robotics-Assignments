import rclpy
from rclpy.node import Node
from custom_interfaces.srv import MyPgkSrv 

class TimeService(Node):
    def __init__(self):
        super().__init__('my_service')
        self.srv_ = self.create_service(MyPgkSrv, 'get_status', self.get_status_cb)
        self.get_logger().info('Time Service Started')
        # self.threshold = 10.0

    def get_status_cb(self, request, response):
        self.get_logger().info(f'Request received: {request.current_status}')
            # current_time = self.get_clock().now().to_msg() #converts time to message ros format
            # print("hi lodu ")
            # response.res = current_time
        if request.current_status=='None' and request.operational_state == 'active':
            response.new_task = 5
            response.status = True
        elif request.current_status=='None' and request.operational_state == 'charging':
            response.new_task = 4
            response.status = True

        elif request.current_status=='standby' and request.operational_state == 'active':
            response.new_task = 3
            response.status = True


        else:
            response.new_task = 1  #this constructor does not take any argument, so it will give 0 sec. 0nanosec as output
            response.status = False

        return response

def main(args = None):
    rclpy.init(args = args)
    time_service = TimeService()

    rclpy.spin(time_service)
    rclpy.shutdown()

if __name__ == '__main__':
    main()