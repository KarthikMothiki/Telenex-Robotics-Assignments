import rclpy
from rclpy.node import Node
from custom_interfaces.srv import MyPgkSrv  # Make sure the service is built and imported correctly
import random

class TimeClient(Node):
    def __init__(self):
        super().__init__('time_client')
        self.cli = self.create_client(MyPgkSrv, 'get_status')  # Initialize the name of the service

        timeout = 5.0  # Time to wait for the service to become available

        # Wait for the service to be available
        while not self.cli.wait_for_service(timeout_sec=timeout):
            print(f"Waiting for the service, it's been {timeout} seconds...")

        print('Service is available')
        self.request = MyPgkSrv.Request()  # Initialize the request object

    def send_request(self):
        # Fill in the service request data
        self.request.current_status = random.choice(['task', 'None'])
        self.request.operational_state = random.choice(['active', 'standby', 'charging'])
        # self.request.operational_status = random.choice(['Idle', 'harvesting', 'maintenance'])  # Random status

        # Call the service asynchronously and wait for the result
        self.future = self.cli.call_async(self.request)
        rclpy.spin_until_future_complete(self, self.future)

        # Return the result of the service call
        return self.future.result()

def main(args=None):
    rclpy.init(args=args)
    time_client = TimeClient()  # Create the client node

    response = time_client.send_request()  # Send the request and get the response
    try:
        new_task = response.new_task  # Access the correct response attribute
        print(new_task)
    except:
        print("Service call failed!")

    rclpy.shutdown()  # Shutdown ROS 2

if __name__ == '__main__':
    main()