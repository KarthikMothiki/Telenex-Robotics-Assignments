#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from custom_interfaces.msg import MyPkgMsg
import random

class CustomPublisher(Node):
    def __init__(self, robot_name):
        super().__init__('robot_state_publisher_' + robot_name)
        self.publisher_ = self.create_publisher(MyPkgMsg, f'{robot_name}/state', 10)
        self.robot_name = robot_name
        timer_period = 1.0
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.get_logger().info('Custom Publisher has been started')

    def timer_callback(self):
        msg = MyPkgMsg()
        msg.task_status = random.choice(['Idle', 'Busy'])
        msg.robot_name = self.robot_name
        msg.battery_level = random.uniform(0.0,12.0)
        self.publisher_.publish(msg)
        print(f"Publishing: {msg.task_status}")

def main(args = None):
    rclpy.init(args=args)
    robot_name = 'robot1'  # Dynamically assign robot name
    robot_state_publisher = CustomPublisher(robot_name)
    rclpy.spin(robot_state_publisher)
    robot_state_publisher.destroy_node()
    rclpy.shutdown()

    if __name__ == '__main__':
        main()